![OpenAI ChatGPT 4.1 Global Elite User — Top 0.01%](https://img.shields.io/badge/OpenAI%20User-Top%200.01%25%20Elite-brightgreen?style=for-the-badge&logo=openai)
